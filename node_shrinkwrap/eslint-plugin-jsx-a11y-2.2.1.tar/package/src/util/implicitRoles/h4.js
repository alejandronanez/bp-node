/**
 * Returns the implicit role for an h4 tag.
 */
export default function getImplicitRoleForH4() {
  return 'heading';
}
