/**
 * Returns the implicit role for an article tag.
 */
export default function getImplicitRoleForArticle() {
  return 'article';
}
