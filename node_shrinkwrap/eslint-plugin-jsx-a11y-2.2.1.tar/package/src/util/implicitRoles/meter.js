/**
 * Returns the implicit role for a meter tag.
 */
export default function getImplicitRoleForMeter() {
  return 'progressbar';
}
