/**
 * Returns the implicit role for an h2 tag.
 */
export default function getImplicitRoleForH2() {
  return 'heading';
}
