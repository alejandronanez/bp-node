/**
 * Returns the implicit role for a select tag.
 */
export default function getImplicitRoleForSelect() {
  return 'listbox';
}
