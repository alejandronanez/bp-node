/**
 * Returns the implicit role for an aside tag.
 */
export default function getImplicitRoleForAside() {
  return 'complementary';
}
