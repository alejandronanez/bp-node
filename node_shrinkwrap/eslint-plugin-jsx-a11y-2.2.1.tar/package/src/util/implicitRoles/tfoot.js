/**
 * Returns the implicit role for a tfoot tag.
 */
export default function getImplicitRoleForTfoot() {
  return 'rowgroup';
}
