/**
 * Returns the implicit role for a tbody tag.
 */
export default function getImplicitRoleForTbody() {
  return 'rowgroup';
}
