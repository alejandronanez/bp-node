/**
 * Returns the implicit role for a textarea tag.
 */
export default function getImplicitRoleForTextarea() {
  return 'textbox';
}
