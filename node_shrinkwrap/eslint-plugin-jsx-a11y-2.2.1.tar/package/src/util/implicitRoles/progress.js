/**
 * Returns the implicit role for a progress tag.
 */
export default function getImplicitRoleForProgress() {
  return 'progressbar';
}
