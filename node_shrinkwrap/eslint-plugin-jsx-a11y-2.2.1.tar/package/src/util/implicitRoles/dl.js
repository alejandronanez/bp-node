/**
 * Returns the implicit role for a dl tag.
 */
export default function getImplicitRoleForDl() {
  return 'list';
}
