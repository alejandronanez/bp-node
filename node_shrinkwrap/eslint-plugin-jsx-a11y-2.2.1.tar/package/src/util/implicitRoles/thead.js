/**
 * Returns the implicit role for a thead tag.
 */
export default function getImplicitRoleForThead() {
  return 'rowgroup';
}
